import pygame
import socket
pygame.init()

largura, altura = 900, 800
display = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Bússola")

fundo = (48, 25, 52)  # Roxo

HOST = '127.0.0.1'    # The remote host
PORT = 50007          # The same port as used by the server

imagem_bussola = pygame.image.load('./Bussola/Bussola.png')
imagem_ponteiro = pygame.image.load('./Bussola/ponteiro.png')
imagem_ponteiro = pygame.transform.scale(imagem_ponteiro, (360, 100))

angulo = 0  

# Algoritmos 
def algoritmo1(valor):
    return valor

def algoritmo2(valor):
    return valor * 2

def algoritmo3(valor):
    return valor / 2

def rotacionar_imagem(imagem, angulo):
    return pygame.transform.rotate(imagem, angulo)

def desenhar_menu(display, opcoes, selecionado):
    fonte = pygame.font.Font(None, 36)
    menu_rect = pygame.Rect(50, 50, 230, 40)
    pygame.draw.rect(display, (100, 100, 100), menu_rect)
    texto = fonte.render(opcoes[selecionado], True, (255, 255, 255))
    display.blit(texto, (60, 55))

    return menu_rect

def desenhar_legenda(display, texto):
    fonte = pygame.font.Font(None, 36)
    legenda = fonte.render(texto, True, (255, 255, 255))
    display.blit(legenda, (50, 10))

def main():
    global angulo
    executando = True
    algoritmo_selecionado = 0
    opcoes = ["AoA Classificador", "Regressor", "Fé no Pellenz"]

    menu_aberto = False

    while executando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                executando = False
            elif evento.type == pygame.MOUSEBUTTONDOWN:
                x, y = evento.pos
                if menu_aberto:
                    for i, opcao in enumerate(opcoes):
                        if 50 <= x <= 250 and 90 + i * 40 <= y <= 130 + i * 40:
                            algoritmo_selecionado = i
                            menu_aberto = False
                else:
                    if 50 <= x <= 250 and 50 <= y <= 90:
                        menu_aberto = True

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((HOST, PORT))
                s.listen(1)
                s.settimeout(0.2)
                conn, addr = s.accept()
                with conn:
                    valor = float(conn.recv(1024).decode())
                    if algoritmo_selecionado == 0:
                        angulo = algoritmo1(valor)
                    elif algoritmo_selecionado == 1:
                        angulo = algoritmo2(valor)
                    elif algoritmo_selecionado == 2:
                        angulo = algoritmo3(valor)
                    print(angulo)
            except: pass

        display.fill(fundo)
        display.blit(imagem_bussola, (largura//2 - imagem_bussola.get_width()//2, altura//2 - imagem_bussola.get_height()//2))
        
        ponteiro_rotacionado = rotacionar_imagem(imagem_ponteiro, -angulo)
        display.blit(ponteiro_rotacionado, (largura//2 - ponteiro_rotacionado.get_width()//2, altura//2 - ponteiro_rotacionado.get_height()//2))
        
        desenhar_legenda(display, "Selecione o algoritmo:")
        menu_rect = desenhar_menu(display, opcoes, algoritmo_selecionado)
        if menu_aberto:
            for i, opcao in enumerate(opcoes):
                pygame.draw.rect(display, (100, 100, 100), (50, 90 + i * 40, 230, 40))
                texto = pygame.font.Font(None, 36).render(opcao, True, (255, 255, 255))
                display.blit(texto, (60, 95 + i * 40))
        
        pygame.display.flip()
        pygame.time.delay(100)

    pygame.quit()

if __name__ == "__main__":
    main()